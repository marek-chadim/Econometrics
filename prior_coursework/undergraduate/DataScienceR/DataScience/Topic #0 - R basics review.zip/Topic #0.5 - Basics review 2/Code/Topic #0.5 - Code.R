##LOADING AND TRANSFORMING DATA

#Loading data, well-structured data
uciCar<-read.delim(#Command to read from a file or URL
                  #and store the result in a new data frame object called uciCar.
  "https://github.com/WinVector/zmPDSwR/blob/master/UCICar/car.data.csv", #Filename or URL to get the data from.
# "car.data.csv", #Assuming you have a working directory specified. Otherwise, the whole path needs to be given.
  sep=',',    # Specify the column or field separator as a comma.
  header=T    # Tell R to expect a header line that defines the data column names.
)

#Exploring the data
class(uciCar) #Check the data class.
dim(uciCar) #Always try to confirm you got a good parse by at least checking that the 
            #number of rows is exactly one fewer than the number of lines of text in the original file.

#Loading the credit dataset (less-strcutured dataset)
d<-read.table(paste('http://archive.ics.uci.edu/ml/',
                      'machine-learning-databases/statlog/german/german.data',sep=''),
                        stringsAsFactors=F,header=F)
head(d,3)
class(d)

#Setting column names using the colnames() attribute of the data frame
colnames(d) <- c('Status.of.existing.checking.account',
                 'Duration.in.month',  'Credit.history', 'Purpose',
                 'Credit.amount', 'Savings account/bonds',
                 'Present.employment.since',
                 'Installment.rate.in.percentage.of.disposable.income',
                 'Personal.status.and.sex', 'Other.debtors/guarantors',
                 'Present.residence.since', 'Property', 'Age.in.years',
                 'Other.installment.plans', 'Housing',
                 'Number.of.existing.credits.at.this.bank', 'Job',
                 'Number.of.people.being.liable.to.provide.maintenance.for',
                 'Telephone', 'foreign.worker', 'Good.Loan')

#Changing integers into factors using the combination of as.factor() and ifelse()
d$Good.Loan<-as.factor(ifelse(d$Good.Loan==1,'GoodLoan','BadLoan')) 
head(d,3) #Check the new structure

#When starting from a "coded" dataset (check the actual observations), it might be useful
#to "translate" the codes into the actual meanings (if we have the "dictionary").
#To do so, we first specify a mapping via a list() function.
mapping<-list('A11'='... < 0 DM',
              'A12'='0 <= ... < 200 DM',
              'A13'='... >= 200 DM / salary assignments for at least 1 year',
              'A14'='no checking account',
              'A30'='no credits taken/all credits paid back duly',
              'A31'='all credits at this bank paid back duly',
              'A32'='existing credits paid back duly till now',
              'A33'='delay in paying off in the past',
              'A34'='critical account/other credits existing (not at this bank)',
              'A40'='car (new)',
              'A41'='car (used)',
              'A42'='furniture/equipment',
              'A43'='radio/television',
              'A44'='domestic appliances',
              'A45'='repairs',
              'A46'='education',
              'A47'='(vacation - does not exist?)',
              'A48'='retraining',
              'A49'='business',
              'A410'='others',
              'A61'='... < 100 DM',
              'A62'='100 <= ... < 500 DM',
              'A63'='500 <= ... < 1000 DM',
              'A64'='.. >= 1000 DM',
              'A65'='unknown/ no savings account',
              'A71'='unemployed',
              'A72'='... < 1 year',
              'A73'='1 <= ... < 4 years',
              'A74'='4 <= ... < 7 years',
              'A75'='.. >= 7 years',
              'A91'='male : divorced/separated',
              'A92'='female : divorced/separated/married',
              'A93'='male : single',
              'A94'='male : married/widowed',
              'A95'='female : single',
              'A101'='none',
              'A102'='co-applicant',
              'A103'='guarantor',
              'A121'='real estate',
              'A122'='if not A121 : building society savings agreement/life insurance',
              'A123'='if not A121/A122 : car or other, not in attribute 6',
              'A124'='unknown / no property',
              'A141'='bank',
              'A142'='stores',
              'A143'='none',
              'A151'='rent',
              'A152'='own',
              'A153'='for free',
              'A171'='unemployed/ unskilled - non-resident',
              'A172'='unskilled - resident',
              'A173'='skilled employee / official',
              'A174'='management/ self-employed/highly qualified employee/ officer',
              'A191'='none',
              'A192'='yes, registered under the customers name',
              'A201'='yes',
              'A202'='no')

for(i in 1:(dim(d))[2]) {   #Repeat over all columns in the data frame d. 
  if(class(d[,i])=='character') { #For each column that has a character class
    d[,i] <- as.factor(as.character(mapping[d[,i]])) #re-map the values     
  }
}
head(d,3) #Check how the data frame changed

table(d$Purpose,d$Good.Loan) #Compare the frequencies across different variables.

#Working with relational databases
#Selecting a subset of the Census data 
load('phsample.RData') #Assuming the file is in the working directory
#Selecting a subset of data rows matching detailed employment conditions
psub<-subset(dpus,with(dpus,(PINCP>1000)&(ESR==1)&
                          (PINCP<=250000)&(PERNP>1000)&(PERNP<=250000)&
                          (WKHP>=40)&(AGEP>=20)&(AGEP<=50)&
                          (PWGTP1>0)&(COW %in% (1:7))&(SCHL %in% (1:24))))    

#Recoding variables
head(psub$SEX)
psub$SEX<-as.factor(ifelse(psub$SEX==1,'M','F')) #Reencode sex from 1/2 to M/F.
head(psub$SEX)
psub$SEX<-relevel(psub$SEX,'M') #Make the reference sex M, so F encodes a difference from M in models.
head(psub$SEX)

#Reencode class of worker info into a more readable form.
#First create the mapping
cowmap<-c("Employee of a private for-profit",
            "Private not-for-profit employee",
            "Local government employee",
            "State government employee",
            "Federal government employee",
            "Self-employed not incorporated",
            "Self-employed incorporated")
head(psub$COW,20)

#The rewrite the values with levels specified in the mapping
##De-encoding the steps:
#psub$COW
#cowmap[psub$COW]
#as.factor(cowmap[psub$COW])
psub$COW<-as.factor(cowmap[psub$COW]) 

head(psub$COW,20)
#Reencode education info into a more readable 
#form and fewer levels (merge all levels below high 
#school into same encoding).
schlmap<-c(
  rep("no high school diploma",15),
  "Regular high school diploma",
  "GED or alternative credential",
  "some college credit, no degree",
  "some college credit, no degree",
  "Associate's degree",
  "Bachelor's degree",
  "Master's degree",
  "Professional degree",
  "Doctorate degree")
psub$SCHL<-as.factor(schlmap[psub$SCHL])
psub$SCHL<-relevel(psub$SCHL,schlmap[1])
#dtrain<-subset(psub,ORIGRANDGROUP>=500) #Subset of data rows used for model training.
#dtest<-subset(psub,ORIGRANDGROUP<500) #Subset of data rows used for model testing. 
#summary(dtrain$COW)

##EXPLORING DATA

custdata<-read.table('custdata.tsv',
                       header=TRUE,sep='\t')
head(custdata)
summary(custdata) 
summary(custdata$income)
summary(custdata$age)
Income<-custdata$income/1000
summary(Income[Income>=0])

#Some useful graphical functions for exploring data
hist(custdata$age) #Histogram
plot(density(custdata$age)) #Density plot
barplot(table(custdata$marital.stat)) #Bar charts need to use the table() function as a pre-step
barplot(table(custdata$marital.stat),horiz=T,cex.names=1.2) #Horizontal bar chart
barplot(sort(table(custdata$marital.stat)),horiz=T,cex.names=1.2) #Ordered horizontal bar chart

plot(custdata$age,custdata$income)
plot(custdata$age[custdata$age>0],custdata$income[custdata$income>0]) #Error
plot(custdata$age[custdata$age>0&custdata$income>0],
     custdata$income[custdata$age>0&custdata$income>0])
plot(log10(custdata$age[custdata$age>0&custdata$income>0]), #Log-log
     log(custdata$income[custdata$age>0&custdata$income>0]))
plot(custdata$age[custdata$age>0&custdata$income>0], #Semi-log
     log(custdata$income[custdata$age>0&custdata$income>0]))

##MANAGING DATA

#Cleaning data

load("exampleData.rData")
#Check whether the observations with missing values 
#for the housing.type are the same as for recent.move and num.vehicles
summary(custdata[is.na(custdata$housing.type),
                  #Restrict to the rows where housing.type is NA.
                 c("recent.move","num.vehicles")]
                  #Look only at the columns recent.move and num.vehicles.
        )
         

#Remapping NA to a level
custdata$is.employed.fix<-ifelse(is.na(custdata$is.employed), #If is.employed value is missing...
                                   "missing", #...assign the value "missing". Otherwise...
                                   ifelse(custdata$is.employed==T, #...if is.employed==TRUE, assign the value "employed"...
                                          "employed",
                                          "not employed")) #...or the value "not employed".
#The transformation has turned the variable 
#type from factor to string. It can be changed back 
#with the as.factor() function.
summary(custdata$is.employed.fix)
summary(as.factor(custdata$is.employed.fix))

summary(custdata$income)

meanIncome<-mean(custdata$income,na.rm=T)  #Remove the NAs
Income.fix<-ifelse(is.na(custdata$income), #Substitute the NAs with an average value
                     meanIncome,
                     custdata$income)
summary(Income.fix) #Average remains the same

#Converting missing numeric data to a level

#Select some income ranges of interest. To 
#use the cut() function, the upper and lower bounds 
#should encompass the full income range of the 
#data.
breaks<-c(0,10000,50000,100000,250000,1000000)
#Cut the data into income ranges. The 
#include.lowest=T argument makes sure that zero 
#income data is included in the lowest income range 
#category. By default it would be excluded.
Income.groups<-cut(custdata$income,
                     breaks=breaks, include.lowest=T)
#The cut() function produces factor 
#variables. Note the NAs are preserved. 
summary(Income.groups)
#To preserve the category names before adding 
#   a new category, convert the variables to strings. 
Income.groups<-as.character(Income.groups)
#Add the "no income" category to replace the NAs.
Income.groups<-ifelse(is.na(Income.groups),
                        "no income",Income.groups)
summary(as.factor(Income.groups))

#Tracking original NAs with an extra categorical variable
missingIncome<-is.na(custdata$income)
Income.fix<-ifelse(is.na(custdata$income),0,custdata$income) #Zeros instead of NAs

#Data transformations

#Normalizing income by state 
medianincome<-aggregate(income~state.of.res,custdata,FUN=median) #Calculate median income for each state
colnames(medianincome)<-c('State','Median.Income') #Rename the columns
summary(medianincome)
head(medianincome)
head(custdata)
custdata$Median.Income<-NULL #Get rid of the Median.Income that's already in the dataset

#Merge the original dataset with the medianincome by state
custdata<-merge(custdata,medianincome,by.x="state.of.res",by.y="State")
summary(custdata[,c("state.of.res","income","Median.Income.y")])
head(custdata)

#Normalize by median income, i.e. create a new variable 
#(with () as an alternative to using $ here).
custdata$income.norm<-with(custdata,income/Median.Income.y) 
head(custdata)
#summary(custdata$income.norm)

#Converting continuous into discrete variables

#Simple thresholding
custdata$income_lt_20K <- custdata$income<20000
summary(custdata$income_lt_20K)

#Converting age into ranges
#Select the age ranges of interest. The upper 
#and lower bounds should encompass the full range of the data. 
brks<-c(0,25,65,Inf)
custdata$age.range<-cut(custdata$age,
                          breaks=brks,
                            include.lowest=T)
summary(custdata$age.range) #The output of cut() is a factor variable.

#Normalization and rescaling
summary(custdata$age)
meanage<-mean(custdata$age)
custdata$age.normalized<-custdata$age/meanage #Normalize with respect to the mean age
summary(custdata$age.normalized)
stdage<-sd(custdata$age)
custdata$age.normalized<-(custdata$age-meanage)/stdage #Typical normalization
summary(custdata$age.normalized)

#Taking logs but controlling for negative values
signedlog10<-function(x) {
  ifelse(abs(x)<=1,0,sign(x)*log10(abs(x)))
}
signedlog10(c(-10,-5,-1,-0.5,0,0.5,1,5,10))

##Sampling for modeling and validation

#Creating a sample group column
custdata$gp<-runif(dim(custdata)[1]) #Number of rows represents the number of observations
testSet<-subset(custdata,custdata$gp<=0.1) #10% for the testing set
trainingSet<-subset(custdata,custdata$gp>0.1) #90% for the training set

#For grouped datasets
hhdata$gp<-NULL
hh<-unique(hhdata$household_id) #Get all unique household IDs from your data frame.
#Create a temporary data frame of household IDs and a uniformly random number from 0 to 1.
households<-data.frame(household_id = hh, gp = runif(length(hh)))
#households<-data.frame(household_id = sample(hh,length(hh),replace=F))
#Merge new random sample group column back into original data frame.
hhdata<-merge(hhdata, households, by="household_id")
