################################################################################
################# 5304 Econometrics Autumn 2023 PS5        #####################
################# Suggested solutions by Petter Berg (TA)  #####################
################################################################################

################################################################################
######################## PRELIMINARIES AND LOADING DATA ######################## 
################################################################################

# Clearing workspace
rm(list=objects())

# Loading packages
library(rio)
library(tidyverse)
library(stargazer)
library(sandwich)
library(gridExtra)
library(statar)
library(did)

# Setting root
root = "C:/Dropbox/SAKER/Petter/PhD Economics/TA/5304 Econometrics/PS_5"
datapath = paste0(root,"/Data/")
outpath = paste0(root,"/Output/R/")

# Loading data
dat <- import(paste0(datapath,"/PS5_AngristAcemoglu01.dta"))

################################################################################
################################### PROGRAMS ################################### 
################################################################################

# There are two coefplot functions in R, one coming from the coefplot package and
# one from fixest. Both are pretty bad in my opinion. The first one builds on 
# ggplot, which is great, but doesn't allow us to use e.g. robust or clustered
# standard errors in an easy way. The second (from fixest) doesn't build on 
# ggplot, which just makes it... well, not ideal, because ggplot is so good.

# Therefore, I make my own coefplot function here that builds on ggplot. It's
# not very customizable and is only a sketch for a full program, but works for
# our purposes.

my_coefplot <- function(lm_object, setype, keep) {
  require(ggplot2)
  require(sandwich)
  
  # Computing SEs
  se <- sqrt(diag(vcovHC(lm_object, type=setype)))
  
  # Picking out coefficients in "keep"
  coefs <- lm_object$coefficients[names(lm_object$coefficients) %in% keep]
  se <- se[names(se) %in% keep]
  
  # Creating base ggplot object
  fig <- ggplot(data=data.frame(names=names(coefs),coefs=coefs,se=se),
                mapping=aes(x=names,y=coefs)) +
    geom_point() +
    geom_errorbar(aes(ymin=coefs-1.96*se,ymax=coefs+1.96*se),
                  width=.2, position=position_dodge(.9))
  return(fig)
}

################################################################################
################################### ANALYSIS ################################### 
################################################################################

# Setting ggplot style settings
themesettings <- theme(title = element_text(size=17),
                       axis.text.y = element_text(size=13),
                       axis.title.y = element_text(size=17),
                       axis.title.x = element_text(size=17),
                       axis.text.x = element_text(size=13),
                       legend.text = element_text(size=15),
                       strip.text.x = element_text(size=15),
                       plot.background = element_rect(fill="white"),
                       panel.background = element_rect(fill="white", colour="grey50"),
                       panel.grid.major = element_line(colour="grey90"),
                       panel.grid.minor = element_line(colour="grey90"),
                       plot.title = element_text(hjust = 0.5),
                       legend.position="bottom")

# Generating variables and preparing,
dat <- dat %>% filter(incbus==0) %>%
  mutate(year_work = year-1,
         disabled = case_when(disabwrk == 2 ~ 1, TRUE ~ 0))

# Converting to factors
dat <- dat %>%
  mutate(year_work = factor(year_work),
         disabled = factor(disabled),
         age = factor(age),
         race = factor(race),
         educrec = factor(educrec),
         region = factor(region))

# Plotting time trends of disabled vs. non-disabled workers
dat.fig1 <- dat %>% group_by(year_work, disabled) %>% summarise(avgwkswork = mean(wkswork1))

fig1 <- ggplot(data=dat.fig1, aes(x=year_work, y=avgwkswork, group=disabled, color=disabled)) +
  geom_line() +
  geom_vline(xintercept=1992, color="red") +
  themesettings + xlab("Working year") + ylab("Weeks worked") +
  scale_y_continuous(breaks=seq(10,50,10), limits = c(10,50)) +
  scale_colour_manual(name = "disabled", values = c("red","blue")) +
  theme(legend.position = "bottom")
ggsave(paste0(outpath,"Fig1_R.png"),plot=fig1, width=14, height=10.1)

# Dynamic DID regression (without controls)
d_did <- lm(wkswork1 ~ year_work*disabled, dat)

# Keeping only relevant coefficients and running "my_coefplot"
keep = paste0("year_work",c(1988:1996),":disabled1")
fig2_1 <- my_coefplot(d_did,"HC3",keep=keep) + themesettings +
  geom_hline(yintercept=0) +
  geom_vline(xintercept="year_work1992:disabled1", color="red") +
  scale_x_discrete(labels=c(1987:1996)) +
  scale_y_continuous(breaks=c(-6,-4,-2,0,2)) +
  ylab("Point estimates") + xlab("Year") +
  ggtitle("Effects on weeks worked (no controls)")
ggsave(filename=paste0(outpath,"/Fig2_1_R.png"), fig2_1)

# Dynamic DID regression (with controls)
d_did_controls <- lm(wkswork1 ~ year_work*(disabled + age + race + educrec + region), dat)

# Outputting plot (takes pretty long due to computing the entire cov matrix, could be made more efficient)
fig2_2 <- my_coefplot(d_did_controls,"HC3",keep=keep) + themesettings +
  geom_hline(yintercept=0) +
  geom_vline(xintercept="year_work1992:disabled1", color="red") +
  scale_x_discrete(labels=c(1987:1996)) +
  scale_y_continuous(breaks=c(-6,-4,-2,0,2)) +
  ylab("Point estimates") + xlab("Year") +
  ggtitle("Effects on weeks worked (w. controls)")
ggsave(filename=paste0(outpath,"/Fig2_2_R.png"), fig2_2)


# Simulation exercise

# Loading data
dat2 <- import(paste0(datapath,"PS5_simulated.dta"))
dat2$country <- factor(dat2$country)

# Plotting potential outcomes
fig3a <- ggplot(data=dat2, aes(x=year, y=Y1, group=country, color=country)) +
  geom_line(size=1) + geom_point() +
  themesettings + xlab("Year") + ylab("Y(1)") +
  scale_colour_manual(name = "country", values = c("blue","red","green")) +
  scale_y_continuous(breaks=seq(0,22,2), limits=c(0,22))

fig3b <- ggplot(data=dat2, aes(x=year, y=Y0, group=country, color=country)) +
  geom_line(size=1) + geom_point() +
  themesettings + xlab("Year") + ylab("Y(0)") +
  scale_colour_manual(name = "country", values = c("blue","red","green")) +
  scale_y_continuous(breaks=seq(0,22,2), limits=c(0,22))

ggsave(paste0(outpath,"Fig3_R.png"),arrangeGrob(fig3a,fig3b,ncol=2), width=14, height=10.1)

# Plotting actual outcomes
fig4 <- ggplot(data=dat2, aes(x=year, y=Y, group=country, color=country)) +
  geom_line(size=1) + geom_point() +
  themesettings + xlab("Year") + ylab("Y (observed)") +
  scale_colour_manual(name = "country", values = c("blue","red","green")) +
  scale_y_continuous(breaks=seq(0,22,2), limits=c(-1,22))
ggsave(paste0(outpath,"Fig4_R.png"),fig4, width=14, height=10.1)

# Computing ATT
att_all <- dat2 %>% filter(treatment==1) %>% mutate(TE = Y1-Y0) %>%
    summarise(ATT = mean(TE)) %>% as.numeric() # ~8.41

# Estimating ATT by TWFE
twfe1 <- lm(Y ~ treatment + factor(country) + factor(year), dat2) # Substantially off!

# Estimating ATT by TWFE when dropping country 3
twfe2 <- lm(Y ~ treatment + factor(country) + factor(year), filter(dat2,country!=3))
att_without3 <- dat2 %>% filter(treatment==1 & country!=3) %>% mutate(TE = Y1-Y0) %>%
  summarise(ATT = mean(TE)) %>% as.numeric() # ~8.41 

# Estimating ATT with Callaway & Sant'Anna (2021) estimator

# Generating a variable containing information on the time period at which the
# group was first treated (never-treated are coded as 0)
dat2 <- dat2 %>% mutate(gv = case_when(country == 2 ~ 2014,
                                       country == 3 ~ 2017,
                                       TRUE ~ 0))
dat2$country <- as.numeric(dat2$country) # id variable needs to be numeric

# DR DD with Male+Age covariates (doesn't seem to work for some reason?)
atts <- att_gt(yname = "Y", # LHS variable
               tname = "year", # time variable
               idname = "country", # id variable
               gname = "gv", # first treatment period variable
               data = dat2, # data
               xformla = NULL, # no covariates
               est_method = "reg", # "dr" is doubly robust. "ipw" is inverse probability weighting. "reg" is regression
               control_group = "notyettreated", # set the comparison group which is either "nevertreated" or "notyettreated"
               panel=TRUE) 
aggte(atts, type="simple")

  
  
  
