install.packages("kernlab")

####KERNELS####

#Applying stepwise linear regression to PUMS data
load("psub.RData")
#Split data into test and training.
dtrain<-subset(psub,ORIGRANDGROUP>=500)
dtest<-subset(psub,ORIGRANDGROUP<500)

#Basic OLS:
#Stepwise regression (based on AIC optimization):
stepReg<-step( #Step function 
  lm(log(PINCP,base=10)~AGEP+SEX+COW+SCHL, #Specify the model
     data=dtrain), 	#Specify the dataset
  direction="both", #Specify the selection procedure/direction
  steps=100, #Specify maximum number of steps
  k=log(length(dtrain)) #Penalty function as if maximizing BIC
  ) 
summary(stepReg)
#RMSE function:
rmse<-function(y,f){
  sqrt(mean((y-f)^2)) 
}
#Check the testing performance
print(rmse(log(dtest$PINCP,base=10),
           predict(stepReg,newdata=dtest)))

#Using explicit kernel transform
#Define our primal kernel function: map 
#a vector to a copy of itself plus all 
#square terms and cross-multiplied terms:
phi<-function(x) {
  x<-as.numeric(x)
  c(x,x*x,combn(x,2,FUN=prod))
}

#The same kernel principle but with variable names
#instead of values: 
phiNames<-function(n){
  c(n,paste(n,n,sep=":"), #n:n gives a square
    combn(n,2,FUN=function(x) {paste(x,collapse=":")})) #other combinations
}

#Convert data to a matrix where all categorical variables
#are converted into separate dummy variables:
modelMatrix<-model.matrix(~0+AGEP+SEX+COW+SCHL,psub) #0 for no intercept (we don't want to combine intercepts)
head(modelMatrix)
dim(modelMatrix)

#Substitute problematic characters from matrix 
#column names to underscores:
colnames(modelMatrix)<-gsub("[^a-zA-Z0-9]+","_", #code for a space
                            colnames(modelMatrix))
#Apply the primal kernel function to every 
#row of the matrix and transpose results so they're written as rows
#(apply() returns a vector/column for each row):
pM<-t(apply(modelMatrix,1,phi))
vars<-phiNames(colnames(modelMatrix))
vars<-gsub("[^a-zA-Z0-9]+","_",vars) #Just to be sure
#Extend names from original matrix to 
#names for compound variables in new matrix:
colnames(pM)<-vars
pM<-as.data.frame(pM)
#Add in outcomes, test/train split 
#columns, and prepare new data for modeling:
pM$PINCP<-psub$PINCP
pM$ORIGRANDGROUP<-psub$ORIGRANDGROUP
pMtrain<-subset(pM,ORIGRANDGROUP>=500)
pMtest<-subset(pM,ORIGRANDGROUP<500)

formulaStr2<-paste("log(PINCP,base=10)",
                   paste(vars,collapse="+"),
                   sep="~")
model<-lm(as.formula(formulaStr2),data=pMtrain)
summary(model)
dim(summary(model)$coefficients)
#stepModel<-step(lm(as.formula(formulaStr2),data=pMtrain),direction="both") #Very time-consuming
stepModel<-step(lm(as.formula(formulaStr2),data=pMtrain),direction="backward",
                steps=100,
                k=log(length(pMtrain)))
summary(stepModel)
coef2<-summary(model)$coefficients
colnames(coef2)
interestingVars<-setdiff(rownames(coef2)[coef2[,"Pr(>|t|)"]<0.10],
                         "(Intercept)")
#Select a set of interesting variables by building
#an initial model using all of the new 
#variables and retaining an interesting subset. 
interestingVars<-union(colnames(modelMatrix),interestingVars)
formulaStr3<-paste("log(PINCP,base=10)",
                   paste(interestingVars,collapse="+"),
                   sep="~")
#Stepwise regression on subset of variables to 
#get a new model. 
modelInt<-step(lm(as.formula(formulaStr3),data=pMtrain),direction="both",
               steps=100,
               k=log(length(pMtrain)))
length(modelInt$coefficients)
length(interestingVars)
summary(modelInt)
#Calculate the RMSE between the prediction and the actuals. 
print(rmse(log(pMtest$PINCP,base=10),predict(modelInt,newdata=pMtest)))
#The original model:
print(rmse(log(dtest$PINCP,base=10),
           predict(stepReg,newdata=dtest)))
rownames(summary(modelInt)$coefficients)
rownames(summary(stepReg)$coefficients)

####SUPPORT(ING) VECTOR MACHINES####

#Spirals dataset
library("kernlab")
data("spirals")
#View(spirals)
plot(spirals[,1],spirals[,2])
#Use kernlab's spectral clustering routine 
#to identify the two different spirals in the example dataset.
sc<-specc(spirals,centers=2)
#Combine the spiral coordinates and the 
#spiral label into a data frame. 
print(sc)
s<-data.frame(x=spirals[,1],y=spirals[,2],
              class=as.factor(sc))
#Plot spirals with class labels.
plot(s$x[s$class==1],s$y[s$class==1],col="red",
     xlim=c(min(s$x),max(s$x)),ylim=c(min(s$y),max(s$y)))
points(s$x[s$class==2],s$y[s$class==2],col="blue")

#SVM, Example 1:
set.seed(2335246L)
#Split the dataset into training and testing samples.
s$group<-sample.int(100,size=dim(s)[[1]],replace=T)
sTrain<-subset(s,group>10)
sTest<-subset(s,group<=10)
#Build the support vector model using a 
#vanilladot kernel (not a very good kernel for this case).
mSVMV<-ksvm(class~x+y,data=sTrain,
            kernel="vanilladot")
sTest$predSVMV<-predict(mSVMV,newdata=sTest,type="response")
plot(sTrain$x[sTrain$class==1],sTrain$y[sTrain$class==1],col="red",
     xlim=c(min(s$x),max(s$x)),ylim=c(min(s$y),max(s$y)))
points(sTrain$x[sTrain$class==2],sTrain$y[sTrain$class==2],col="blue")
points(sTest$x[sTest$predSVMV==1],sTest$y[sTest$predSVMV==1],col="orangered4")
points(sTest$x[sTest$predSVMV==2],sTest$y[sTest$predSVMV==2],col="purple4")

plot(sTest$x[sTest$predSVMV==1],sTest$y[sTest$predSVMV==1],col="orangered4",
     xlim=c(min(s$x),max(s$x)),ylim=c(min(s$y),max(s$y)))
points(sTest$x[sTest$predSVMV==2],sTest$y[sTest$predSVMV==2],col="purple4")

#Accuracy
hitRate<-sum(sTest$class==sTest$predSVMV)/length(sTest$predSVMV)
hitRate

#Rerun Example 1 with:
#sTrain<-subset(s,group>50)
#sTest<-subset(s,group<=50)

#SVM, Example 2:
#This time use the "radial" or 
#Gaussian kernel, which is a nice geometric similarity measure. 
mSVMG<-ksvm(class~x+y,data=sTrain,
            kernel="rbfdot")
sTest$predSVMG<-predict(mSVMG,newdata=sTest,type="response")
plot(sTrain$x[sTrain$class==1],sTrain$y[sTrain$class==1],col="red",
     xlim=c(min(s$x),max(s$x)),ylim=c(min(s$y),max(s$y)))
points(sTrain$x[sTrain$class==2],sTrain$y[sTrain$class==2],col="blue")
points(sTest$x[sTest$predSVMG==1],sTest$y[sTest$predSVMG==1],col="orangered4")
points(sTest$x[sTest$predSVMG==2],sTest$y[sTest$predSVMG==2],col="purple4")
plot(sTest$x[sTest$predSVMG==1],sTest$y[sTest$predSVMG==1],col="orangered4",
     xlim=c(min(s$x),max(s$x)),ylim=c(min(s$y),max(s$y)))
points(sTest$x[sTest$predSVMG==2],sTest$y[sTest$predSVMG==2],col="purple4")
hitRate<-sum(sTest$class==sTest$predSVMG)/length(sTest$predSVMG)
hitRate

#Using SVMs on real data
#Preparing the data
spamD<-read.table("spamD.tsv",header=T,sep="\t")
spamTrain<-subset(spamD,spamD$rgroup>=10)
spamTest<-subset(spamD,spamD$rgroup<10)
spamVars<-setdiff(colnames(spamD),list("rgroup","spam"))

#Fitting the logistic regression
spamFormula<-as.formula(paste('spam=="spam"',
                              paste(spamVars,collapse=" + "),sep=" ~ "))
spamModel<-glm(spamFormula,family=binomial(link="logit"),
               data=spamTrain)
spamTest$pred<-predict(spamModel,newdata=spamTest,
                       type="response")
print(with(spamTest,table(y=spam,glPred=pred>=0.5)))

#Applying the SVMs
#library("kernlab")

spamTrain$spamFactor<-as.factor(spamTrain$spam)
spamTest$spamFactor<-as.factor(spamTest$spam)

spamFormulaV<-as.formula(paste("spamFactor",
                               paste(spamVars,collapse=" + "),sep=" ~ "))

svmM<-ksvm(spamFormulaV,data=spamTrain,
           #Ask for the radial dot or Gaussian kernel 
           #(in fact the default kernel). 
           kernel="rbfdot",
           C=10, 	#Set the "soft margin penalty" high
           #Explicitly control the trade-off between 
           #false positive and false negative errors.
           #Here false positive is a big mistake, i.e. penalized a lot.
           class.weights=c("spam"=1,"non-spam"=10)
)
spamTest$svmPred<-predict(svmM,newdata=spamTest,type="response")
#head(spamTest)
tableSVM<-(with(spamTest,table(y=spam,svmPred=svmPred)))
print(tableSVM)
print(with(spamTest,table(y=spam,glPred=pred>=0.5)))

#Comparing SVMs and logistic regression results
#Find the threshold for the same number of predicted positives.
sameCut<-sort(spamTest$pred)[length(spamTest$pred)-sum(tableSVM[,2])] 
#Print the logistic regression table with the new threshold.
print(with(spamTest,table(y=spam,glPred=pred>sameCut)))
print(tableSVM)
