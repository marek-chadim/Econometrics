install.packages(c("car","lars","mgcv"))

#################################
####### LINEAR REGRESSION #######
#################################

#Working with a pre-prepared .RData file. 
#Check the differences in calling objects/variables from the data.

load("psub.RData")
dim(psub) #check number of observations and variables
names(psub) #check the names
hist(psub$ORIGRANDGROUP) #ORIGRANDGROUP is a randomization factor
dtrain<-subset(psub,ORIGRANDGROUP>=500)
dtest<-subset(psub,ORIGRANDGROUP<500)
dim(dtrain)[2]/(dim(dtrain)[2]+dim(dtest)[2]) #Check the 50/50 ratio

#R loads categorical variables as indicators. These are then treated separately in the regression.
#No need to create new dummy variables here.
summary(psub$COW)
summary(psub$SCHL)

#Estimate the model on the dtrain data
model<-lm(log(PINCP,base=10)~AGEP+SEX+COW+SCHL,data=dtrain)
#Predict using the in-sample model for in-sample (dtrain) and out-of-sample (dtest) data
dtest$predLogPINCP<-predict(model,newdata=dtest) 
dtrain$predLogPINCP<-predict(model,newdata=dtrain)

#Coefficient of determination
R2<-function(y,pred) {
  #Function is based on the standard definition of
  #R2=1-SSR/SST
  #For actual prediction (out-of-sample), SSR changes into
  #the sum of squared prediction errors
  1-sum((y-pred)^2)/sum((y-mean(y))^2) 
} 
#In-sample R2
R2(log(dtrain$PINCP,base=10),predict(model,newdata=dtrain))
#Out-of-sample R2
R2(log(dtest$PINCP,base=10),predict(model,newdata=dtest))

#Root mean ssquared error
rmse<-function(y,pred) {
  #An alternative measure of model quality
  #Can be seen as a measure of the width of the data 
  #around the line of perfect prediction
  sqrt(mean((y-pred)^2)) 
} 
rmse(log(dtrain$PINCP,base=10),predict(model,newdata=dtrain))
rmse(log(dtest$PINCP,base=10),predict(model,newdata=dtest))

summary(model) #Interpret
#plot(model)
names(model) 
names(summary(model)) #Values of lm() and summary(lm()) are a bit different
plot(model$fitted.values,log(dtrain$PINCP,base=10))
plot(predict(model,newdata=dtest),log(dtest$PINCP,base=10))

#####################
####### LASSO #######
#####################

#The model.matrix statement defines the model to be fitted
library(lars)
x<-model.matrix(log(PINCP,base=10)~AGEP+SEX+COW+SCHL,data=dtrain)
head(x)
x<-x[,-1] #getting rid of the constant term
lasso<-lars(x=x,y=log(dtrain$PINCP,base=10),trace=TRUE) #trace sets whether to print the progress
#Trace of lasso (standardized) coefficients for varying penalty
lasso
plot(lasso) #variable selection process
coef(lasso,s=c(.25,.50,0.75,1.0),mode="fraction") #coefficient values as functions of shrinkage
#Cross-validation using 100 folds
cv.lars(x=x,y=log(dtrain$PINCP,base=10),K=100)

xx<-model.matrix(log(PINCP,base=10)~AGEP*(SEX+COW+SCHL)^2,data=dtrain) #larger independent variables pool
xx<-xx[,-1] #getting rid of the constant term
dim(x)
dim(xx) #compare the number of independent variables
lasso_xx<-lars(x=xx,y=log(dtrain$PINCP,base=10),trace=FALSE)
#plot(lasso_xx)
#lasso
coef(lasso_xx,s=seq(0,1,by=0.2),mode="fraction")
#Cross-validation using 33 folds
cv<-cv.lars(x=xx,y=log(dtrain$PINCP,base=10),K=33)
names(cv)
plot(cv$index,cv$cv,type="l")
cv_min<-cv$index[cv$cv==min(cv$cv)] #Find the optimal shrinkage parameter
coefs<-coef(lasso_xx,s=cv_min,mode="fraction")
coefs[coefs!=0] #Just the non-zero estimates (the ones not zeroed out)
length(coefs[coefs!=0])
length(coefs[coefs!=0])/length(coefs)

#Predictions with LASSO
dtrain$predLogPINCP_LASSO<-predict(lasso_xx,xx,s=cv_min,mode="fraction")$fit
xx_pred<-model.matrix(log(PINCP,base=10)~AGEP*(SEX+COW+SCHL)^2,data=dtest)
xx_pred<-xx_pred[,-1]
dtest$predLogPINCP_LASSO<-predict(lasso_xx,xx_pred,s=cv_min,mode="fraction")$fit
plot(dtest$predLogPINCP,dtest$predLogPINCP_LASSO)

dtrain$predLogPINCP_OLS<-predict(lasso_xx,xx,s=1,mode="fraction")$fit
dtest$predLogPINCP_OLS<-predict(lasso_xx,xx_pred,s=1,mode="fraction")$fit

#In-sample
R2(log(dtrain$PINCP,base=10),dtrain$predLogPINCP)
R2(log(dtrain$PINCP,base=10),dtrain$predLogPINCP_LASSO)
R2(log(dtrain$PINCP,base=10),dtrain$predLogPINCP_OLS)

#Out-of-sample
R2(log(dtest$PINCP,base=10),dtest$predLogPINCP)
R2(log(dtest$PINCP,base=10),dtest$predLogPINCP_LASSO)
R2(log(dtest$PINCP,base=10),dtest$predLogPINCP_OLS)

###################################
####### LOGISTIC REGRESSION #######
###################################

rm(list=ls()) #Remove all objects

#Loading data and spliting the dataset
load("NatalRiskData.rData")
names(sdata)
#Divide into training and testing sets based on
#the predefined randomization variable
train<-sdata[sdata$ORIGRANDGROUP<=5,]
test<-sdata[sdata$ORIGRANDGROUP>5,]

#Specifying dependent and independent variables
complications<-c("ULD_MECO","ULD_PRECIP","ULD_BREECH")
riskfactors<-c("URF_DIAB","URF_CHYPER","URF_PHYPER","URF_ECLAM")
y<-"atRisk"
x<-c("PWGT","UPREVIS","CIG_REC","GESTREC3","DPLURAL",complications,riskfactors)
#Function for glm() can be "pasted" together
fmla<-paste(y, paste(x, collapse="+"),sep="~")
fmla

#Estimating the model 
#Don't forget to specify "logit"
model<-glm(fmla,data=train,family=binomial(link="logit"))
summary(model)

#Making (in-sample and out-of-sample) predictions
#For logit, type="response" needs to be specified to return probabilities
train$pred<-predict(model,newdata=train,type="response")
test$pred<-predict(model,newdata=test,type="response")

#Finding model's precision
threshold<-0.02 #We need to set a threshold first
ctab.test<-table(pred=test$pred>threshold,atRisk=test$atRisk)
ctab.test
#Precision: the predicted positives are true positives
precision<-ctab.test[2,2]/sum(ctab.test[2,])
#Recall: how many of the true positives the classifier finds
recall<-ctab.test[2,2]/sum(ctab.test[,2])
#Mind the denominator difference between precision and recall
#Enrichment: ratio of the classifier precision to the average rate of positives
enrich<-precision/mean(as.numeric(test$atRisk))

#Run for a set of thresholds
step<-0.005 #Set a step to vary thresholds
#Empty matrix for results
threshMeasures<-matrix(rep(NA,4*(0.5/step+1)),ncol=4)
i<-1 #Counting parameter
for(threshold in seq(0,0.5,step)){
  #Rerun the code code for precision, recall and enrich for given threshold
  ctab.test<-table(pred=test$pred>threshold,atRisk=test$atRisk)
  #Conditional on a complete table
  if(dim(ctab.test)[1]==2&dim(ctab.test)[2]==2){ 
    precision<-ctab.test[2,2]/sum(ctab.test[2,])
    recall<-ctab.test[2,2]/sum(ctab.test[,2])
    enrich<-precision/mean(as.numeric(test$atRisk))
    #Write into the matrix
    threshMeasures[i,1]<-threshold
    threshMeasures[i,2]<-precision
    threshMeasures[i,3]<-recall
    threshMeasures[i,4]<-enrich  
    i<-i+1
    rm(ctab.test) #Remove ctab.test (just to be sure)
  }
}
threshMeasures
#Use only the filled part of the matrix
results<-matrix(c(threshMeasures[!is.na(threshMeasures)]),ncol=4)
#Add names
colnames(results)<-c("Threshold","Precision","Recall","Enrichment")
results
#Plot only y-values>0
plot(results[,1][results[,2]>0],results[,2][results[,2]>0],type="l")
plot(results[,1][results[,3]>0],results[,3][results[,3]>0],type="l")

#In one chart
plot(results[,1][results[,2]>0],results[,2][results[,2]>0],type="l",col="red")
lines(results[,1][results[,3]>0],results[,3][results[,3]>0],col="green")

###############################
##GENERALIZED ADDITIVE MODELS##
###############################

#Generating data.
set.seed(602957)
nobs<-1000 #Specify number of observations
x<-rnorm(nobs)
noise<-rnorm(nobs,sd=1.5)
y<-3*sin(2*x)+cos(0.75*x)-1.5*(x^2)+noise #Generate y
plot(x,y)

#Splitting the dataset into training and testing sets.
select<-runif(nobs) #Splitting variable
frame<-data.frame(y=y,x=x)
train<-frame[select>0.1,] #90% of data as a training set
test<-frame[select<=0.1,] #10% of data as a testing set

#Estimating the model using OLS
lin.model<-lm(y~x,data=train) #Estimate the linear regression
summary(lin.model)
fitted.lin<-lin.model$fitted.values #Get the fitted values
plot(train$x,train$y,xlab="x",ylab="y (circles), fitted values (line)")
lines(train$x,fitted.lin,type="l",col="red")
resid.lin<-lin.model$residuals #Get residuals
sqrt(mean(resid.lin^2)) #RMSE

#Applying the GAM
library(mgcv) #Package for GAMs 
glin.model<-gam(y~s(x),data=train) #Specifying x as a nonlinear parameter
glin.model$converged #Has the procedure converged?
summary(glin.model)
names(glin.model) #Check the object details.
?gamObject
glin.model$null.deviance
glin.model$deviance
glin.model$aic
names(summary(glin.model)) #Check the object details.
summary(glin.model)$edf
resid.glin<-glin.model$residuals
sqrt(mean(resid.glin^2)) #RMSE

#Comparing the testing performance
actual<-test$y
pred.lin<-predict(lin.model,newdata=test)
pred.glin<-predict(glin.model,newdata=test)
resid.lin<-actual-pred.lin
resid.glin<-actual-pred.glin

#Comparing RMS(F)E
sqrt(mean(resid.lin^2))
sqrt(mean(resid.glin^2))

#Comparing prediction correlations
cor(actual,pred.lin)^2
cor(actual,pred.glin)^2

#Trying GAM on real data
load("NatalBirthData.rData")
train<-sdata[sdata$ORIGRANDGROUP<=5,] #Split the dataset 50-50
test<-sdata[sdata$ORIGRANDGROUP>5,] #Split the dataset 50-50
form.lin<-as.formula("DBWT~PWGT+WTGAIN+MAGER+UPREVIS") #Specify the formula
linmodel<-lm(form.lin,data=train) #Estimate the model
summary(linmodel)

#Specify the formula, specifying splines as s()
form.glin<-as.formula("DBWT~s(PWGT)+s(WTGAIN)+s(MAGER)+s(UPREVIS)")
glinmodel<-gam(form.glin,data=train) #Estimate the model
glinmodel$converged #Has the estimation converged?
summary(glinmodel)

pred.lin<-predict(linmodel,newdata=test) #Predictions from the testing dataset
pred.glin<-predict(glinmodel,newdata=test) #Predictions from the testing dataset

cor(pred.lin,test$DBWT)^2 #R^2 for predictions (OLS)
cor(pred.glin,test$DBWT)^2 #R^2 for predictions (GAM)

#GAMs for logistic regression

#Using the same dataset, creating a formula with a 0-1 variable
form<-as.formula("DBWT<2000~PWGT+WTGAIN+MAGER+UPREVIS")
#Logit model:
logmod<-glm(form,data=train,family=binomial(link="logit"))
summary(logmod)

#GAM-logit model:
form2<-as.formula("DBWT<2000~s(PWGT)+s(WTGAIN)+s(MAGER)+s(UPREVIS)")
glogmod<-gam(form2, data=train,family=binomial(link="logit"))
glogmod$converged
summary(glogmod)
