## CREATING A DATASET

# Types of vectors
a <- c(1, 2, 5, 3, 6, -2, 4) # numeric
b <- c("one", "two", "three") # character
c <- c(TRUE, TRUE, TRUE, FALSE, TRUE, FALSE) # logical
d<-c(T,F,T)

# Subsetting vectors
a <- c("k", "j", "h", "a", "c", "m")
a[3]
a[c(1, 3, 5)]
a[2:6]

# Creating matrices
y <- matrix(1:20, nrow = 5, ncol = 4)
y
cells <- c(1, 26, 24, 68)
rnames <- c("R1", "R2")
cnames <- c("C1", "C2")
mymatrix <- matrix(cells,
                   nrow = 2, ncol = 2, byrow = TRUE,
                   dimnames = list(rnames, cnames))
mymatrix
mymatrix <- matrix(cells,
                   nrow = 2, ncol = 2, byrow = FALSE,
                   dimnames = list(rnames, cnames))
mymatrix

# Using matrix subscripts
x <- matrix(1:10, nrow = 2)
x
x[2, ]
x[, 2]
x[1, 4]
x[1, c(4, 5)]
x[c(1,2),c(3,4,5)]
x[1:2,3:5]

# Creating an array
dim1 <- c("A1", "A2")
dim2 <- c("B1", "B2", "B3")
dim3 <- c("C1", "C2", "C3", "C4")
z <- array(1:24, c(2, 3, 4), dimnames = list(dim1, dim2, dim3))
z
z[1,1,1]
z["A1","B2","C3"]

# Creating a data frame
patientID <- c(1, 2, 3, 4)
age <- c(25, 34, 28, 52)
diabetes <- c("Type1", "Type2", "Type1", "Type1")
status <- c("Poor", "Improved", "Excellent", "Poor")
patientdata <- data.frame(patientID, age, diabetes, status)
patientdata

#Set case identifier
patientdata <- data.frame(age, diabetes, status,
                          row.names=patientID)
patientdata

# Specifying elements of a data frame
patientdata[1:2]
patientdata$age
patientdata[c("diabetes", "status")]
table(patientdata$diabetes, patientdata$status)

# with()
with(mtcars, {
  summary(mpg, disp, wt)
  plot(mpg, disp)
  plot(mpg, wt)
})

with(mtcars, {
  stats <- summary(mpg)
  stats
})
stats

with(mtcars, {
  nokeepstats <- summary(mpg)
  keepstats <<- summary(mpg)
})
nokeepstats
keepstats

# Using factors
patientID <- c(1, 2, 3, 4)
age <- c(25, 34, 28, 52)
diabetes <- c("Type1", "Type2", "Type1", "Type1")
status <- c("Poor", "Improved", "Excellent", "Poor")
diabetes <- factor(diabetes)
status <- factor(status, order = TRUE)
patientdata <- data.frame(patientID, age, diabetes, status)
str(patientdata) #structure of the object
summary(patientdata)

# Creating a list
g <- "My First List"
h <- c(25, 26, 18, 39)
j <- matrix(1:10, nrow = 5)
k <- c("one", "two", "three")
mylist <- list(title = g, ages = h, j, k)
mylist
mylist[[2]]
mylist[2] #returns a list
class(mylist[2])
class(mylist[[2]])
mylist[["ages"]]
mylist$ages

#Some useful functions
length(patientdata$age)
dim(patientdata)
str(patientdata)
class(patientdata)
mode(patientdata)
length(names(patientdata))
head(patientdata,2)
tail(patientdata,2)
ls() 
rm(list=ls()) #removes all objects

## BASIC DATA MANAGEMENT

# Creating the leadership data frame
leadership <- data.frame(
  manager = c(1, 2, 3, 4, 5),
  date    = c("10/24/08", "10/28/08", "10/1/08", "10/12/08", "5/1/09"),
  country = c("US", "US", "UK", "UK", "UK"),
  gender  = c("M", "F", "F", "M", "F"),
  age     = c(32, 45, 25, 39, 99),
  q1      = c(5, 3, 3, 3, 2),
  q2      = c(4, 5, 5, 3, 2),
  q3      = c(5, 2, 5, 4, 1),
  q4      = c(5, 5, 5, NA, 2),
  q5      = c(5, 5, 2, NA, 1)
)
leadership

# Creating new variables
leadership$total_score  <-  leadership$q1 + leadership$q2 + 
  leadership$q3 + leadership$q4 + leadership$q5
leadership

leadership$mean_score <- (leadership$q1 + leadership$q2 + leadership$q3 + 
                            leadership$q4 + leadership$q5)/5
leadership

leadership$total_score<-NULL
leadership$mean_score<-NULL
leadership

leadership <- transform(leadership,
                        total_score  =  q1 + q2 + q3 + q4 + q5,
                        mean_score = (q1 + q2 + q3 + q4 + q5)/5)
leadership

#Recoding variables
leadership2<-leadership
leadership2$age[leadership$age==99] <- NA

leadership2$agecat[leadership2$age>75]<-"Elder"
leadership2$agecat[leadership2$age>=55 & leadership$age<=75] <- "Middle Aged"
leadership2$agecat[leadership2$age < 55] <- "Young"
leadership2

leadership3<-leadership
leadership3 <- within(leadership3,{
  agecat <- NA
  agecat[age > 75 & age < 99] <- "Elder"
  agecat[age >= 55 & age <= 75] <- "Middle Aged"
  agecat[age < 55] <- "Young"
  }
)
leadership3

names(leadership3)[6:10] <- c("item1", "item2", "item3", "item4", "item5")

# Apply the is.na() function
y <- c(1, 2, 3, NA)
is.na(y)

is.na(leadership[,6:10])

#Missing values and arithmetic functions
x <- c(1, 2, NA, 3)
x[1] + x[2] + x[3] + x[4]
sum(x)

sum(x, na.rm=TRUE)

# Using na.omit() to delete incomplete observations
leadership
newdata <- na.omit(leadership)    
newdata

# Converting from one data type to another
a <- c(1,2,3)
a
is.numeric(a)
is.vector(a)
a <- as.character(a)
a
is.numeric(a)
is.vector(a)
is.character(a)

#Sorting
newdata <- leadership[order(leadership$age),]
newdata <- leadership[order(leadership$gender, leadership$age),]

#Selecting variables
newdata <- leadership[, c(6:10)]

myvars <- c("q1", "q2", "q3", "q4", "q5") 
newdata1 <-leadership[myvars]

#Dropping variables
myvars <- names(leadership) %in% c("q3", "q4")
newdata <- leadership[!myvars]

newdata1 <- leadership[c(-8,-9)]

leadership3<-leadership
leadership3$q3 <- leadership3$q4 <- NULL

# Selecting observations
newdata <- leadership[1:3,]
newdata <- leadership[leadership$gender=="M" &
                        leadership$age > 30,]

#The subset() function
newdata <- subset(leadership, age >= 35 | age < 24,
                  select=c(q1, q2, q3, q4))
newdata <- subset(leadership, gender=="M" & age > 25,
                  select=gender:q4)

## ADVANCED DATA MANAGEMENT
# install.packages(c("MultiRNG", "tidyr", "dplyr")) 

#Calculating the mean and standard deviation
x <- c(1, 2, 3, 4, 5, 6, 7, 8)
# short way
mean(x)
sd(x)
# long way
n <- length(x)
meanx <- sum(x) / n
css <- sum((x - meanx)^2)
sdx <- sqrt(css / (n - 1))
meanx
sdx

#Plot normal curve
library(ggplot2)
x <- seq(from = -3, to = 3, by = 0.1)
y <- dnorm(x)
data <- data.frame(x = x, y = y)
ggplot(data, aes(x, y)) +
  geom_line() +
  labs(x = "Normal Deviate",
       y = "Density") +
  scale_x_continuous(breaks = seq(-3, 3, 1))

#Generating pseudo-random numbers from a uniform distribution
runif(5)
runif(5)
set.seed(1234)
runif(5)
set.seed(1234)
runif(5)

#Generating data from a multivariate normal distribution
library(MultiRNG)
options(digits = 3)
set.seed(1234)

mean <- c(230.7, 146.7, 3.6)
sigma <- matrix(c(15360.8, 6721.2, -47.1,
                  6721.2, 4700.9, -16.5,
                  -47.1,  -16.5,   0.3), 
                nrow = 3, ncol = 3)

mydata <- draw.d.variate.normal(500, 3, mean, sigma)
mydata <- as.data.frame(mydata)
names(mydata) <- c("y", "x1", "x2")

dim(mydata)
head(mydata, n = 10)
hist(mydata$x2)

#Applying functions to data objects
set.seed(1234)
a <- 5
sqrt(a)
b <- c(1.243, 5.654, 2.99)
round(b)
c <- matrix(runif(12), nrow = 3)
c
log(c)
mean(c)

#Applying a function to the rows (columns) of a matrix
mydata <- matrix(rnorm(30), nrow = 6)
mydata
apply(mydata, 1, mean)
apply(mydata, 2, mean)
apply(mydata, 2, mean, trim = 0.2)

#A solution to the learning example
options(digits = 2)

Student <- c("John Davis", "Angela Williams", "Bullwinkle Moose",
             "David Jones", "Janice Markhammer", "Cheryl Cushing",
             "Reuven Ytzrhak", "Greg Knox", "Joel England",
             "Mary Rayburn")
Math <- c(502, 600, 412, 358, 495, 512, 410, 625, 573, 522)
Science <- c(95, 99, 80, 82, 75, 85, 80, 95, 89, 86)
English <- c(25, 22, 18, 15, 20, 28, 15, 30, 27, 18)
roster <- data.frame(Student, Math, Science, English,
                     stringsAsFactors = FALSE)

z <- scale(roster[, 2:4])
score <- apply(z, 1, mean)
roster <- cbind(roster, score)

y <- quantile(score, c(.8, .6, .4, .2))

roster$grade <- NA
roster$grade[score >= y[1]] <- "A"
roster$grade[score < y[1] & score >= y[2]] <- "B"
roster$grade[score < y[2] & score >= y[3]] <- "C"
roster$grade[score < y[3] & score >= y[4]] <- "D"
roster$grade[score < y[4]] <- "F"

name <- strsplit((roster$Student), " ")
Lastname <- sapply(name, "[", 2) #"[" extracts the part of the list
Firstname <- sapply(name, "[", 1)
roster <- cbind(Firstname, Lastname, roster[, -1])

roster <- roster[order(Lastname, Firstname), ]

roster

#For loop
for (i in 1:10)  print("Hello")
for (i in 1:10)  {print("Hello"); print(i)}
for (i in 1:10)  {
  print("Hello")
  print(i)
}

for (i in c("Hello", ", how", "are", "you", "?")){
  print(i)
}

#While loop
i <- 10
while (i > 0) {print("Hello"); i <- i - 1; print(i)}

#An if-else example
grade<-c("first")
#grade<-c(1)
if (is.character(grade)) grade <- as.factor(grade)
class(grade)
if (!is.factor(grade)) grade <- as.factor(grade) else print("Grade already is a factor")
grade

#An ifelse example
score<-0.7
outcome <- ifelse (score > 0.5, "Passed", "Failed")

#A switch example
feelings <- c("sad", "afraid")
for (i in feelings) {
  print(
    switch(i,
           happy  = "I am glad you are happy",
           afraid = "There is nothing to fear",
           sad    = "Cheer up",
           angry  = "Calm down now"
    )
  )
}

#mystats(): a user-written function for summary statistics
mystats <- function(x, parametric = TRUE, print = FALSE) {
  if (parametric) {
    center <- mean(x)
    spread <- sd(x)
  } else {
    center <- median(x)
    spread <- mad(x)
  }
  if (print & parametric) {
    cat("Mean=", center, "\n", "SD=", spread, "\n")
  } else if (print & !parametric) {
    cat("Median=", center, "\n", "MAD=", spread, "\n")
  }
  result <- list(center = center, spread = spread)
  return(result)
}

set.seed(1234)
x <- rnorm(500)
y <- mystats(x)
y <- mystats(x, parametric=FALSE, print=TRUE)
class(y)

#Transposing a dataset
cars <- mtcars[1:5, 1:4]
cars
t(cars)

#Converting a wide format data frame to a long format
library(tidyr)

data_wide <- data.frame(ID = c("AU", "CN", "PRK"),
                        Country = c("Australia", "China", "North Korea"),
                        LExp1990 = c(76.9, 69.3, 69.9),
                        LExp2000 = c(79.6, 72.0, 65.3),
                        LExp2010 = c(82.0, 75.2, 69.6))
data_wide


data_long <- gather(data_wide, 
                    key = "Variable", 
                    value = "Life_Exp",
                    c(LExp1990, LExp2000, LExp2010))
data_long

#Converting a long format data frame to a wide format
data_wide <- spread(data_long, key = Variable, value = Life_Exp)
data_wide

#Aggregating data with the aggregate() function
options(digits = 3)
aggdata <- aggregate(mtcars,
                     by = list(mtcars$cyl, mtcars$gear),
                     FUN = mean, na.rm = TRUE)
aggdata

#Improved code for aggregating data with aggregate()
aggdata <- aggregate(mtcars[-c(2, 10)],
                     by = list(Cylinders = mtcars$cyl, Gears = mtcars$gear),
                     FUN = mean, na.rm = TRUE)
aggdata
