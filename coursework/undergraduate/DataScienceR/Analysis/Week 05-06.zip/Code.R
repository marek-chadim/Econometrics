# Getting started with graphs                                #

# requires the ggplot2 and mosaicData packages               #
# install.packages(c("ggplot2", "mosaicData"))               #

# -- Section 4.1 Creating a graph with ggplot2
library(ggplot2)
library(mosaicData)
data(CPS85)

# Figure 4.1 Mapping worker experience and wages to the x and y axes
ggplot(data = CPS85, mapping = aes(x = exper, y = wage))

# Figure 4.2 Scatterplot of worker experience vs wages
ggplot(data = CPS85, mapping = aes(x = exper, y = wage)) +
  geom_point()

# Figure 4.3 Scatterplot of worker experience vs. wages with outlier removed
CPS85 <- CPS85[CPS85$wage < 40, ]
ggplot(data = CPS85, mapping = aes(x = exper, y = wage)) +
  geom_point()

# Figure 4.4 Scatterplot of worker experience vs. wages with outlier removed
# with modified point color, transparency, and point size
ggplot(data = CPS85, mapping = aes(x = exper, y = wage)) +
  geom_point(color = "cornflowerblue", alpha = .7, size = 1.5) +
  theme_bw()

# Figure 4.5 Scatterplot of worker experience vs. wages
# with a line of best fit
ggplot(data = CPS85, 
       mapping = aes(x = exper, y = wage)) +
  geom_point(color = "cornflowerblue", alpha = .7, size = 1.5) +
  theme_bw() +
  geom_smooth(method = "lm")

# Figure 4.6 Scatterplot of worker experience vs. wages
# with points colored by sex and separate line of best
# fit for men and women.
ggplot(data = CPS85, 
       mapping = aes(x = exper, y = wage,
                     color = sex, shape = sex, linetype = sex)) +
  geom_point(alpha = .7, size = 1.5) +
  geom_smooth(method = "lm", se = FALSE, size = 1.5) +
  theme_bw()

# Figure 4.7 Scatterplot of worker experience vs. wages
# with custom x- and y-axes and custom color mappings for sex.
ggplot(data = CPS85,
  mapping = aes(x = exper, y = wage,
                color = sex, shape = sex, linetype = sex)) +
  geom_point(alpha = .7, size = 1.5) +
  geom_smooth(method = "lm", se = FALSE, size = 1.5) +
  scale_x_continuous(breaks = seq(0, 60, 10)) +
  scale_y_continuous(breaks = seq(0, 30, 5)) +
  scale_color_manual(values = c("indianred3", "cornflowerblue")) +
  theme_bw()

# Figure 4.8 Scatterplot of worker experience vs. wages with
# custom x- and y-axes and custom color mappings for sex.
# Wages are printed in dollar format.
ggplot(
  data = CPS85,
  mapping = aes(x = exper, y = wage,
                color = sex, shape = sex, linetype = sex)) +
  geom_point(alpha = .7, size = 1.5) +
  geom_smooth(method = "lm", se = FALSE, size = 1.5) +
  scale_x_continuous(breaks = seq(0, 60, 10)) +
  scale_y_continuous(breaks = seq(0, 30, 5),
                     label = scales::dollar) +
  scale_color_manual(values = c("indianred3", "cornflowerblue")) +
  theme_bw()

# Figure 4.9 Scatterplot of worker experience vs. wages with
# custom x- and y-axes and custom color mappings for sex.
# Separate graphs (facets) are provided for each of 8 job sectors.
ggplot(
  data = CPS85,
  mapping = aes(x = exper, y = wage,
                color = sex, shape = sex, linetype = sex)) +
  geom_point(alpha = .7) +
  geom_smooth(method = "lm", se = FALSE) +
  scale_x_continuous(breaks = seq(0, 60, 10)) +
  scale_y_continuous(breaks = seq(0, 30, 5),
                     label = scales::dollar) +
  scale_color_manual(values = c("indianred3", "cornflowerblue")) +
  facet_wrap(~sector) +
  theme_bw()

# Figure 4.10 Scatterplot of worker experience vs. wages
# with separate graphs (facets) for each of 8 job sectors
# and custom titles and labels.
ggplot(
  data = CPS85,
  mapping = aes(x = exper, y = wage,
                color = sex, shape = sex, linetype = sex)) +
  geom_point(alpha = .7) +
  geom_smooth(method = "lm", se = FALSE) +
  scale_x_continuous(breaks = seq(0, 60, 10)) +
  scale_y_continuous(breaks = seq(0, 30, 5),
                     label = scales::dollar) +
  scale_color_manual(values = c("indianred3","cornflowerblue")) +
  facet_wrap(~sector) +
  labs(title = "Relationship between wages and experience",
       subtitle = "Current Population Survey",
       caption = "source: http://mosaic-web.org/",
       x = " Years of Experience",
       y = "Hourly Wage",
       color = "Gender", shape = "Gender", linetype = "Gender") +
  theme_bw()

# Figure 4.11 Scatterplot of worker experience vs. wages
# with separate graphs (facets) for each of 8 job sectors
# and custom titles and labels, and a cleaner theme.

ggplot(data = CPS85,
       mapping = aes(x = exper, y = wage, color = sex, shape=sex,
                     linetype = sex)) +
  geom_point(alpha = .7) +
  geom_smooth(method = "lm", se = FALSE) +
  scale_x_continuous(breaks = seq(0, 60, 10)) +
  scale_y_continuous(breaks = seq(0, 30, 5),
                     label = scales::dollar) +
  scale_color_manual(values = c("indianred3", "cornflowerblue")) +
  facet_wrap(~sector) +
  labs(title = "Relationship between wages and experience",
       subtitle = "Current Population Survey",
       caption = "source: http://mosaic-web.org/",
       x = " Years of Experience",
       y = "Hourly Wage",
       color = "Gender", shape="Gender", linetype="Gender") +
  theme_minimal()

# -- Section 4.2 ggplot2 details

# Figure 4.12. Scatterplot of experience and wage by sex,
# where aes(color=sex) is placed in the ggplot() function.
# The mapping is applied to both the geom_point() and geom_smooth(),
# producing separate point colors for males and females,
# along with separate lines of best fit
ggplot(CPS85,
       mapping = aes(x = exper, y = wage, color = sex)) +
  geom_point(alpha = .7, size = 1.5) +
  geom_smooth(method = "lm", se = FALSE, size = 1)

# Figure 4.13 Scatterplot of experience and wage by sex,
# where aes(color=sex) is placed in the geom_point() function.
# The mapping is applied to point color producing separate point
# colors for men and women, but a single line of best fit
# for or all workers.
ggplot(CPS85, aes(x = exper, y = wage)) +
  geom_point(alpha = .7, size = 1.5) +
  geom_smooth(aes(color = sex), method = "lm", se = FALSE, size = 1)

# Listing 4.1 Using a ggplot2 graph as an object
data(CPS85, package = "mosaicData")
CPS85 <- CPS85[CPS85$wage < 40, ]

myplot <- ggplot(data = CPS85, aes(x = exper, y = wage)) +
  geom_point()

myplot

myplot2 <- myplot + geom_point(size = 3, color = "blue")
myplot2

myplot + geom_smooth(method = "lm") +
  labs(title = "Mildly interesting graph")

#section 4.2.3
ggplot(data=mtcars, aes(x=mpg)) + geom_histogram()
ggsave(file="mygraph.pdf")

# section 4.2.4
# Listing 4.15

#Mistake:
#ggplot(CPS85, aes(x = exper, y = wage, color = sex)) +
#         geom_point()

ggplot(CPS85, aes(x = exper, y = wage, color = "blue")) +
  geom_point()

#vs.

ggplot(CPS85, aes(x = exper, y = wage)) +
         geom_point(color = "blue")
       
# Basic graphs                                                          #
# requires the ggplot2, vcd, dplyr, treemapfiy and scales packages      #
# install.packages(c("ggplot2", "vcd", "dplyr", "treemapify", "scales", "remotes", "devtools", "ggpie"))# 

# Listing 6.1 Simple bar charts
library(ggplot2)
data(Arthritis, package="vcd")
ggplot(Arthritis, aes(x=Improved, fill=Improved)) + geom_bar() +
  labs(title="Simple Bar chart",                 
       x="Improvement",                          
       y="Frequency")                            

ggplot(Arthritis, aes(x=Improved)) + geom_bar() +
  labs(title="Horizontal Bar chart",             
       x="Improvement",                          
       y="Frequency") +                          
  coord_flip()                                   

# Listing 6.2 Stacked, grouped, and filled bar charts
table(Arthritis$Improved, Arthritis$Treatment)

#Stacked
ggplot(Arthritis, aes(x=Treatment, fill=Improved)) +
  geom_bar(position = "stack") +  
  labs(title="Stacked Bar chart",                   
       x="Treatment",                               
       y="Frequency")                               

#Grouped
ggplot(Arthritis, aes(x=Treatment, fill=Improved)) +
  geom_bar(position = "dodge") + 
  labs(title="Grouped Bar chart",                   
       x="Treatment",                               
       y="Frequency")                               

#Filled
ggplot(Arthritis, aes(x=Treatment, fill=Improved)) +
  geom_bar(position = "fill") +  
  labs(title="Filled Bar chart",                   
       x="Treatment",                               
       y="Proportion") 

# Listing 6.3 Bar chart for sorted mean values
states <- data.frame(state.region, state.x77)    

library(dplyr)                 
plotdata <- states %>% 
  group_by(state.region) %>%
  summarize(mean = mean(Illiteracy))
plotdata

ggplot(plotdata, aes(x=reorder(state.region, mean), y=mean)) + 
  geom_bar(stat="identity") +
  labs(x="Region",
       y="",
       title = "Mean Illiteracy Rate")

# Listing 6.4 Bar chart of mean values with error bars
plotdata <- states %>%
  group_by(state.region) %>%
  summarize(n=n(), 
            mean = mean(Illiteracy),                      
            se = sd(Illiteracy)/sqrt(n))                  

plotdata

ggplot(plotdata, aes(x=reorder(state.region, mean), y=mean)) +
  geom_bar(stat="identity", fill="skyblue") +
  geom_errorbar(aes(ymin=mean-se, ymax=mean+se), width=0.2) +
  labs(x="Region",
       y="",
       title = "Mean Illiteracy Rate",
       subtitle = "with standard error bars")

# Figure 6.5 Bar chart
data(Arthritis, package="vcd")
ggplot(Arthritis, aes(x=Improved)) + 
  geom_bar(fill="gold", color="black") +
  labs(title="Treatment Outcome") 

# Bar chart labels
ggplot(mpg, aes(x=model)) + 
  geom_bar() +
  labs(title="Car models in the mpg dataset", 
       y="Frequency", x="") 

ggplot(mpg, aes(x=model)) + 
  geom_bar() +
  labs(title="Car models in the mpg dataset", 
       y="Frequency", x="") +
  coord_flip() 

ggplot(mpg, aes(x=model)) + 
  geom_bar() +
  labs(title="Model names in the mpg dataset", 
       y="Frequency", x="") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, size=8)) 

# Listing 6.6 Simple Tree Map
library(ggplot2)
library(dplyr)
library(treemapify)

plotdata <- mpg %>% count(manufacturer)

ggplot(plotdata,
       aes(fill = manufacturer,
           area = n,
           label = manufacturer)) +
  geom_treemap() +
  geom_treemap_text() +
  theme(legend.position = "none")

# Listing 6.7 Tree Map with Subgrouping
plotdata <- mpg %>%  
  count(manufacturer, drv)
plotdata$drv <- factor(plotdata$drv, 
                       levels=c("4", "f", "r"),
                       labels=c("4-wheel", "front-wheel", "rear"))

ggplot(plotdata,
       aes(fill = manufacturer, 
           area = n,
           label = manufacturer,
           subgroup=drv)) +
  geom_treemap() + 
  geom_treemap_subgroup_border() +
  geom_treemap_subgroup_text(
    place = "middle",
    colour = "black",
    alpha = 0.5,
    grow = FALSE) +
  geom_treemap_text(colour = "white", 
                    place = "centre",
                    grow=F) +
  theme(legend.position = "none")

# Listing 6.8 Histograms
library(ggplot2)
library(scales)

data(mpg)
cars2008 <- mpg[mpg$year == 2008, ]

ggplot(cars2008, aes(x=cty)) + 
  geom_histogram() +
  labs(title="Default histogram")

ggplot(cars2008, aes(x=cty)) + 
  geom_histogram(bins=20, color="white", fill="steelblue") +
  labs(title="Colored histogram with 20 bins",
       x="Highway Miles Per Gallon",
       y="Frequency")

ggplot(cars2008, aes(x=cty, y=..density..)) + 
  geom_histogram(bins=20, color="white", fill="steelblue") +
  scale_y_continuous(labels=scales::percent) +
  labs(title="Histogram with percentages",
       y= "Percent",
       x="Highway Miles Per Gallon")

ggplot(cars2008, aes(x=cty, y=..density..)) +
  geom_histogram(bins=20, color="white", fill="steelblue") + 
  scale_y_continuous(labels=scales::percent) +
  geom_density(color="red", size=1) +
  labs(title="Histogram with density curve",
       y="Percent" ,
       x="Highway Miles Per Gallon")

# Listing 6.9 Kernel density plots
data(mpg, package="ggplot2")
cars2008 <- mpg[mpg$year == 2008, ]

ggplot(cars2008, aes(x=cty)) + 
  geom_density() + 
  labs(title="Default kernel density plot") 

ggplot(cars2008, aes(x=cty)) + 
  geom_density(fill="gold", color="red") + 
  labs(title="Filled kernel density plot")

ggplot(cars2008, aes(x=cty)) + 
  geom_density(fill="red", bw=0.5) +
  labs(title="Kernel density plot with bw=0.5")

# Listing 6.10 Comparative kernel density plots
data(mpg, package="ggplot2")
cars2008 <- mpg[mpg$year == 2008 & mpg$cyl != 5,]
cars2008$Cylinders <- factor(cars2008$cyl)

ggplot(cars2008, aes(x=cty, color=Cylinders, linetype=Cylinders)) +
  geom_density(size=1)  +
  labs(title="Fuel Efficiecy by Number of Cylinders",
       x = "City Miles per Gallon")

ggplot(cars2008, aes(x=cty, fill=Cylinders)) + 
  geom_density() +
  labs(title="Fuel Efficiecy by Number of Cylinders",
       x = "City Miles per Gallon")

# Box plots
ggplot(mtcars, aes(x="", y=mpg)) +
  geom_boxplot() +
  labs(y = "Miles Per Gallon", x="", title="Box Plot")

cars <- mpg[mpg$cyl != 5, ]
cars$Cylinders <- factor(cars$cyl)
cars$Year <- factor(cars$year)
ggplot(cars, aes(x=Cylinders, y=cty)) + 
  geom_boxplot() +
  labs(x="Number of Cylinders", 
       y="Miles Per Gallon", 
       title="Car Mileage Data")

ggplot(cars, aes(x=Cylinders, y=cty)) + 
  geom_boxplot(notch=TRUE, 
               fill="steelblue",
               varwidth=TRUE) +
  labs(x="Number of Cylinders", 
       y="Miles Per Gallon", 
       title="Car Mileage Data")

ggplot(cars, aes(x=Cylinders, y=cty, fill=Year)) +           
  geom_boxplot() +                                           
  labs(x="Number of Cylinders",                              
       y="Miles Per Gallon",                                 
       title="City Mileage by # Cylinders and Year") +    
  scale_fill_manual(values=c("gold", "green"))      

# Listing 6.11 Violin plots
cars <- mpg[mpg$cyl != 5, ]
cars$Cylinders <- factor(cars$cyl)

ggplot(cars, aes(x=Cylinders, y=cty)) + 
  geom_boxplot(width=0.2, 
               fill="green") +
  geom_violin(fill="gold", 
              alpha=0.3) +
  labs(x="Number of Cylinders", 
       y="City Miles Per Gallon", 
       title="Violin Plots of Miles Per Gallon")

# Dot plots
plotdata <- mpg %>%
  filter(year == "2008") %>%
  group_by(model) %>%
  summarize(meanHwy=mean(hwy))
plotdata

ggplot(plotdata, aes(x=meanHwy, y=model)) + 
  geom_point() +
  labs(x="Miles Per Gallon", 
       y="", 
       title="Gas Mileage for Car Models")

ggplot(plotdata, aes(x=meanHwy, y=reorder(model, meanHwy))) + 
  geom_point() +
  labs(x="Miles Per Gallon", 
       y="", 
       title="Gas Mileage for Car Models",
       subtitle = "with standard error bars")
