Click "Stata_101.doc" to start the training

Be sure to extract all files from the zipped folder before beginning the training. 

If you need assistance or have any feedback on any of the training resources, please contact IPA Research Support at researchsupport@poverty-action.org