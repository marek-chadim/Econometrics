################################################################################
################# 5304 Econometrics Autumn 2023 PS4        #####################
################# Suggested solutions by Petter Berg (TA)  #####################
################################################################################

################################################################################
######################## PRELIMINARIES AND LOADING DATA ######################## 
################################################################################

# Clearing workspace
rm(list=objects())

# Loading packages
library(rio)
library(tidyverse)
library(stargazer)
library(sandwich)
library(gridExtra)
library(statar)
library(ivreg)

# Setting root
root = "C:/Users/SSE/Dropbox/SAKER/Petter/PhD Economics/TA/5304 Econometrics/PS_4"
datapath = paste0(root,"/Data/")
outpath = paste0(root,"/Output/R/")

# Loading data
dat <- import(paste0(datapath,"/PS4_AngristLavy99.dta"))

################################################################################
################################### ANALYSIS ################################### 
################################################################################

# Setting ggplot style settings
themesettings <- theme(title = element_text(size=17),
                       axis.text.y = element_text(size=13),
                       axis.title.y = element_text(size=17),
                       axis.title.x = element_text(size=17),
                       axis.text.x = element_text(size=13),
                       legend.text = element_text(size=15),
                       strip.text.x = element_text(size=15),
                       plot.background = element_rect(fill="white"),
                       panel.background = element_rect(fill="white", colour="grey50"),
                       panel.grid.major = element_line(colour="grey90"),
                       panel.grid.minor = element_line(colour="grey90"),
                       plot.title = element_text(hjust = 0.5))

# Trimming the sample to include only the three lowest cutoffs
dat <- dat %>% filter(between(cohort_size,0,160))

# Plotting first stage and reduced form relationships
# Generating identicator for being in each respective bin
dat <- dat %>% mutate(cutoff_bin = case_when(
  between(cohort_size,0,40) ~ 1,
  between(cohort_size,41,80) ~ 2,
  between(cohort_size,81,120) ~ 3,
  TRUE ~ 4
))

# Actual class size
fig1 <- ggplot(data=dat,mapping=aes(x=cohort_size,y=classize,group=cutoff_bin)) +
  stat_summary_bin(fun="mean",bins=20,geom="point",size=3) +
  geom_smooth(formula=y~x,method="lm", se=FALSE,color="maroon") +
  geom_vline(xintercept = c(41,81,121)) +
  themesettings + xlab("Cohort size") + ylab("Actual class size")
ggsave(paste0(outpath,"Fig1_R.png"),plot=fig1, width=14, height=10.1)

# Average math score
fig2 <- ggplot(data=dat,mapping=aes(x=cohort_size,y=avgmath,group=cutoff_bin)) +
  stat_summary_bin(fun="mean",bins=20,geom="point",size=3) +
  geom_smooth(formula=y~x,method="lm", se=FALSE,color="maroon") +
  geom_vline(xintercept = c(41,81,121)) +
  themesettings + xlab("Cohort size") + ylab("Avg. math score")
ggsave(paste0(outpath,"Fig2_R.png"),plot=fig2, width=14, height=10.1)

# Average reading score
fig3 <- ggplot(data=dat,mapping=aes(x=cohort_size,y=avgverb,group=cutoff_bin)) +
  stat_summary_bin(fun="mean",bins=20,geom="point",size=3) +
  geom_smooth(formula=y~x,method="lm", se=FALSE,color="maroon") +
  geom_vline(xintercept = c(41,81,121)) +
  themesettings + xlab("Cohort size") + ylab("Avg. reading score")
ggsave(paste0(outpath,"Fig3_R.png"),plot=fig3, width=14, height=10.1)

# Keeping only lowest cutoff
dat <- dat %>% filter(cohort_size<81)

# Generating RD variables
dat <- dat %>% mutate(
  cohort_size_recentered = cohort_size - 41,
  above = case_when(cohort_size > 40 ~ 1, TRUE ~ 0),
  cohort_size_recentered_above = cohort_size_recentered*above
)

# Running first stage and reduced form regressions, as well as 2SLS
first_stage <- lm(classize ~ above + cohort_size_recentered + cohort_size_recentered_above, dat)
first_stage_se <- sqrt(diag(vcovHC(first_stage, type="HC3")))

reduced_form <- lm(avgmath ~ above + cohort_size_recentered + cohort_size_recentered_above, dat)
reduced_form_se <- sqrt(diag(vcovHC(reduced_form, type="HC3")))

tsls <- ivreg(
  avgmath ~ classize + cohort_size_recentered + cohort_size_recentered_above |
            above + cohort_size_recentered + cohort_size_recentered_above,
  data=dat)
tsls_se <- sqrt(diag(vcovHC(tsls, type="HC3")))

# Outputting
stargazer(first_stage,reduced_form,tsls, out=paste0(outpath,"Tab1_R.tex"),
          title="Fuzzy RDD regressions",
          header=FALSE, digits=3,
          se=list(first_stage_se,reduced_form_se,tsls_se),
          keep.stat = "n")



