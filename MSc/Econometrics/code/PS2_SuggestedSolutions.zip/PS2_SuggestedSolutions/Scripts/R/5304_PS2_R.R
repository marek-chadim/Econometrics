################################################################################
################# 5304 Econometrics Autumn 2023 PS2        #####################
################# Suggested solutions by Petter Berg (TA)  #####################
################################################################################

################################################################################
######################## PRELIMINARIES AND LOADING DATA ######################## 
################################################################################

# Clearing workspace
rm(list=objects())

# Loading packages
library(rio)
library(tidyverse)
library(stargazer)
library(sandwich)
library(gridExtra)
library(statar)
library(car)

# Setting root
root = "C:/Dropbox/SAKER/Petter/PhD Economics/TA/5304 Econometrics 2023/PS_2/PS2_SuggestedSolutions"
datapath = paste0(root,"/Data/")
outpath = paste0(root,"/Output/R/")

# Loading data
dat <- import(paste0(datapath,"/PS1_ANES2020.dta"))

################################################################################
################################### ANALYSIS ################################### 
################################################################################

# Setting ggplot style settings
themesettings <- theme(title = element_text(size=17),
                       axis.text.y = element_text(size=13),
                       axis.title.y = element_text(size=17),
                       axis.title.x = element_text(size=17),
                       axis.text.x = element_text(size=13),
                       legend.text = element_text(size=15),
                       strip.text.x = element_text(size=15),
                       plot.background = element_rect(fill="white"),
                       panel.background = element_rect(fill="white", colour="grey50"),
                       panel.grid.major = element_line(colour="grey90"),
                       panel.grid.minor = element_line(colour="grey90"),
                       plot.title = element_text(hjust = 0.5))

# Looking briefly at the dataset
glimpse(dat)
summary(dat)

# Dropping duplicates
dat <- distinct(dat,respondent_id,.keep_all=TRUE) # 8329 before, 8280 after

# Cleaning data and removing missings
dat <- dat %>% filter(
  president_vote %in% c(1,2) &
  between(age,18,80) &
  between(education,1,8) &
  race >= 0 &
  working >= 0 &
  between(conservative,0,100)
  )

# Generating variables
dat <- dat %>% mutate(
  donald      = case_when(president_vote == 2 ~ 1, TRUE ~ 0),
  high_educ   = case_when(education >= 6 ~ 1, TRUE ~ 0 ),
  white       = case_when(race==1 ~ 1, TRUE ~ 0),
  not_working = case_when(working==2 ~ 1, TRUE ~ 0)
  ) 

# Generating quintiles and quadratics of age
dat <- dat %>% mutate(age2 = age^2,
                      age_quant = xtile(age,5))

# Running regressions on not working
mod1 <- lm(donald ~ not_working, dat)
mod1se <- sqrt(diag(vcovHC(mod1, type="HC3")))
mod2 <- lm(donald ~ not_working + age, dat)
mod2se <- sqrt(diag(vcovHC(mod2, type="HC3")))
mod3 <- lm(donald ~ not_working + age + age2, dat)
mod3se <- sqrt(diag(vcovHC(mod3, type="HC3")))
mod4 <- lm(donald ~ not_working + factor(age_quant), dat)
mod4se <- sqrt(diag(vcovHC(mod4, type="HC3")))
mod5 <- lm(donald ~ not_working + age + age2 + white, dat)
mod5se <- sqrt(diag(vcovHC(mod5, type="HC3")))

# Testing gamma4==gamma2 and gamma5==0
# Estimating robust covariance matrix for mod4
mod4robcov <- vcovHC(mod4, type="HC3")

# Running t-tests
linearHypothesis(mod4, "factor(age_quant)4=factor(age_quant)2", vcov. = mod4robcov) # pval: 0.0005, significant
linearHypothesis(mod4, "factor(age_quant)5=0", vcov. = mod4robcov) # pval: ~0, significant

# Outputting
stargazer(mod1,mod2,mod3,mod4,mod5, out=paste0(outpath,"Tab1_R.tex"),
          title="Regressions of Trump voting no not working and covariates",
          header=FALSE, digits=3,
          se=list(mod1se,mod2se,mod3se,mod4se,mod5se),
          keep.stat = "n")

# Running regressions on the conservative dummy
dat <- dat %>% mutate(conservative_dummy = case_when(conservative > 50 ~ 1, TRUE ~ 0))

mod6 <- lm(donald ~ high_educ, dat)
mod6se <- sqrt(diag(vcovHC(mod6, type="HC3")))
mod7 <- lm(donald ~ high_educ + conservative_dummy, dat)
mod7se <- sqrt(diag(vcovHC(mod7, type="HC3")))

# Outputting
stargazer(mod6,mod7, out=paste0(outpath,"Tab2_R.tex"),
          title="Regressions of Trump voting on education and covariates",
          header=FALSE, digits=3,
          se=list(mod6se,mod7se),
          keep.stat = "n")





