################################################################################
################# 5304 Econometrics Autumn 2023 PS1        #####################
################# Suggested solutions by Petter Berg (TA)  #####################
################################################################################

################################################################################
######################## PRELIMINARIES AND LOADING DATA ######################## 
################################################################################

# Clearing workspace
rm(list=objects())

# Loading packages
library(rio)
library(tidyverse)
library(stargazer)
library(sandwich)
library(gridExtra)
library(xtable)

# Setting root
root = "C:/Users/PE.4991/Dropbox/SAKER/Petter/PhD Economics/TA/5304 Econometrics 2023/PS_1"
datapath = paste0(root,"/Data/")
outpath = paste0(root,"/Output/R/")

# Loading data
dat <- import(paste0(datapath,"/PS1_ANES2020.dta"))

################################################################################
################################### ANALYSIS ################################### 
################################################################################

# Setting ggplot style settings
themesettings <- theme(title = element_text(size=17),
                       axis.text.y = element_text(size=13),
                       axis.title.y = element_text(size=17),
                       axis.title.x = element_text(size=17),
                       axis.text.x = element_text(size=13),
                       legend.text = element_text(size=15),
                       strip.text.x = element_text(size=15),
                       plot.background = element_rect(fill="white"),
                       panel.background = element_rect(fill="white", colour="grey50"),
                       panel.grid.major = element_line(colour="grey90"),
                       panel.grid.minor = element_line(colour="grey90"),
                       plot.title = element_text(hjust = 0.5))

# Looking briefly at the dataset
glimpse(dat)
summary(dat)

# Dropping duplicates
dat <- distinct(dat,respondent_id,.keep_all=TRUE) # 8329 before, 8280 after

# Cleaning data and removing missings
dat <- dat %>% filter(
  president_vote %in% c(1,2) &
  between(age,18,80) &
  between(education,1,8) &
  race >= 0 &
  working >= 0 &
  between(conservative,0,100)
  )

# Generating variables
dat <- dat %>% mutate(
  donald      = case_when(president_vote == 2 ~ 1, TRUE ~ 0),
  high_educ   = case_when(education >= 6 ~ 1, TRUE ~ 0 ),
  white       = case_when(race==1 ~ 1, TRUE ~ 0),
  not_working = case_when(working==2 ~ 1, TRUE ~ 0)
  ) 

# Summary statistics over Trump vs. Biden voters (there are probably better ways to do this,
# but this shows how flexible R is in terms of making tables -- you can just make a matrix in which-
# ever way you want, and export it to .tex and make further outer formatting there, which is nice.)

# Aggregating by Trump voting as well as the full sample (all)
# Note that we are using "sprintf" for formatting (%.2f gives 2 digits), and getting standard errors in parentheses.
dat$one <- 1 # creating a constant
bygroup <- aggregate(cbind(donald, age, not_working, conservative, high_educ, white) ~ donald,
                     dat, function(x) c(mean=sprintf("%.2f", mean(x)),sd=sprintf("(%.2f)", sd(x))))
all <- aggregate(cbind(donald, age, not_working, conservative, high_educ, white) ~ one, 
                 dat, function(x) c(mean=sprintf("%.2f", mean(x)),sd=sprintf("(%.2f)", sd(x)))) # the grouping variable here is constant at 1, so this will aggregate over the entire sample

# Transposing and merging the tables, removing the superfluous first row (the "temporary" variable called "one")
sum <- (cbind(t(bygroup),t(all)))[-1,]

# Adding number of observations at the end
N <- c(dim(filter(dat,donald==1))[1],dim(filter(dat,donald==0))[1],dim(dat)[1])
sum <- rbind(sum,N)

# Renaming columns
colnames(sum) <- c("Biden","Trump","All")
rownames(sum) <- c("Donald (mean)","Donald (sd)","Age (mean)","Age (sd)",
                   "Not working (mean)","Not working (sd)","Conservative (mean)",
                   "Conservative (sd)","High educ (mean)","High educ (sd)",
                   "White (mean)","White (sd)","N")

# Exporting using xtable, nicer than stargazer for summary statistics
table <- xtable(sum, caption="Summary statistics by presidential vote", label="Tab1")
print(table, file=paste0(outpath,"Tab1_R.tex"), caption.placement = "top")


# Generating a histogram of age using ggplot
fig1 <- ggplot(data=dat,mapping=aes(x=age)) +
  geom_histogram(binwidth=1, fill="black", col="grey") +
  themesettings + xlab("Age") + ylab("Frequency")
ggsave(paste0(outpath,"Fig1_R.png"),plot=fig1, width=14, height=10.1)

# Relationship between Trump voting and age

# Normal scatter plot
fig2_bad <- ggplot(data=dat,mapping=aes(x=age,y=donald)) + geom_point() +
  themesettings + xlab("Age") + ylab("Trump vote") # uninterpretable!

# Binned scatter plot with linear and quadratic fits
fig2 <- ggplot(data=dat,mapping=aes(x=age,y=donald)) +
  stat_summary_bin(fun="mean",bins=20,geom="point",size=3) + 
  geom_smooth(formula=y~x,method="lm", se=FALSE,color="maroon") + #linear
  geom_smooth(formula=y~x+I(x^2),method="lm", se=FALSE,color="blue") +
  themesettings + xlab("Age") + ylab("Donald")
ggsave(paste0(outpath,"Fig2_R.png"),plot=fig2, width=14, height=10.1)


# Bar graph with confidence intervals (first computing standard errors)
dat.cibar <- dat %>% group_by(not_working) %>% summarise(m=mean(donald),count=n(),se=sd(donald)/sqrt(count)) # This is the formula for SE of the mean

# Creating figure; confidence interval given by plus/minus 1.96*SE, where 1.96 is the 5% critical value
fig3a <- ggplot(data=dat.cibar,mapping=aes(not_working,m,fill=not_working)) +
  geom_bar(stat="identity", color="black", position=position_dodge()) +
  geom_errorbar(aes(ymin=m-1.96*se,ymax=m+1.96*se), width=.2, position=position_dodge(.9)) +
  scale_x_continuous(breaks=0:1, labels=c("Working","Not working")) +
  scale_y_continuous(breaks=seq(0.3,0.5,by=0.05)) + coord_cartesian(ylim=c(0.3,0.5)) + 
  xlab("") + ylab("Share of Trump voters") + theme(legend.position="none") +
  themesettings + ggtitle("All respondents")

# Filtering out ages 25-55
dat.cibar2 <- dat %>% filter(between(age,25,55)) %>% group_by(not_working) %>%
  summarise(m=mean(donald),count=n(),se=sd(donald)/sqrt(count))

# Creating figure
fig3b <- ggplot(data=dat.cibar2,mapping=aes(not_working,m,fill=not_working)) +
  geom_bar(stat="identity", color="black", position=position_dodge()) +
  geom_errorbar(aes(ymin=m-1.96*se,ymax=m+1.96*se), width=.2, position=position_dodge(.9)) +
  scale_x_continuous(breaks=0:1, labels=c("Working","Not working")) +
  scale_y_continuous(breaks=seq(0.3,0.5,by=0.05)) + coord_cartesian(ylim=c(0.3,0.5)) + 
  xlab("") + ylab("Share of Trump voters") + theme(legend.position="none") +
  themesettings + ggtitle("Ages 25-55")

# Outputting
ggsave(paste0(outpath,"Fig3_R.png"),arrangeGrob(fig3a,fig3b,ncol=2), width=14, height=10.1)




