################################################################################
################# 5304 Econometrics Autumn 2023 PS3        #####################
################# Suggested solutions by Petter Berg (TA)  #####################
################################################################################

################################################################################
######################## PRELIMINARIES AND LOADING DATA ######################## 
################################################################################

# Clearing workspace
rm(list=objects())

# Loading packages
library(rio)
library(tidyverse)
library(stargazer)
library(sandwich)
library(gridExtra)
library(statar)
library(ivreg)

# Setting root
root = "C:/Users/SSE/Dropbox/SAKER/Petter/PhD Economics/TA/5304 Econometrics/PS_3"
datapath = paste0(root,"/Data/")
outpath = paste0(root,"/Output/R/")

# Loading data
dat <- import(paste0(datapath,"/PS3_Campante2014.dta"))


################################################################################
################################### ANALYSIS ################################### 
################################################################################

# Setting ggplot style settings
themesettings <- theme(title = element_text(size=17),
                       axis.text.y = element_text(size=13),
                       axis.title.y = element_text(size=17),
                       axis.title.x = element_text(size=17),
                       axis.text.x = element_text(size=13),
                       legend.text = element_text(size=15),
                       strip.text.x = element_text(size=15),
                       plot.background = element_rect(fill="white"),
                       panel.background = element_rect(fill="white", colour="grey50"),
                       panel.grid.major = element_line(colour="grey90"),
                       panel.grid.minor = element_line(colour="grey90"),
                       plot.title = element_text(hjust = 0.5))


# Keeping only year 1970 and dropping missings
dat <- dat %>% filter(year==1970) %>%
               drop_na()

# Running OLS regression and generating scatter plot
slope <- ((lm(corruptrate_avg ~ ALDmean1970,dat))$coefficient)[2] %>% round(2)

fig1 <- ggplot(dat,aes(x=ALDmean1970,y=corruptrate_avg, label=state_code)) + 
  geom_point(size=3) + geom_text(hjust=1.2,vjust=-0.5) + 
  geom_smooth(formula=y~x, method="lm", se=FALSE) +
  themesettings + xlab("Average Log Distance") + ylab("Average Corruption") +
  scale_y_continuous(breaks=seq(0.1,0.6,0.1)) + 
  geom_text(label=paste0("Slope = ", slope), x=0.45, y = 0.5, size=7)
ggsave(paste0(outpath,"Fig1_R.png"),plot=fig1, width=14, height=10.1)

# Running OLS and IV regressions
mod1 <- lm(corruptrate_avg ~ ALDmean1970, dat)
mod1se <- sqrt(diag(vcovHC(mod1, type="HC3")))
mod2 <- lm(ALDmean1970 ~ centr_ALDmean1970, dat)
mod2se <- sqrt(diag(vcovHC(mod2, type="HC3")))
mod3 <- ivreg(corruptrate_avg ~ ALDmean1970 | centr_ALDmean1970, data=dat)
mod3se <- sqrt(diag(vcovHC(mod3, type="HC3")))
mod4 <- lm(ALDmean1970 ~ centr_ALDmean1970 + logarea + logMaxDistSt, dat)
mod4se <- sqrt(diag(vcovHC(mod4, type="HC3")))
mod5 <- ivreg(corruptrate_avg ~ ALDmean1970 + logarea + logMaxDistSt | centr_ALDmean1970 + logarea + logMaxDistSt, data=dat)
mod5se <- sqrt(diag(vcovHC(mod5, type="HC3")))

# Outputting
stargazer(mod1,mod2,mod3,mod4,mod5, out=paste0(outpath,"Tab1_R.tex"),
          title="OLS and IV regressions of corruption on state capital isolation",
          header=FALSE, digits=3,
          se=list(mod1se,mod2se,mod3se,mod4se,mod5se),
          keep.stat = "n")

# Sensitivity: leave-one-out analysis
point_estimates <- c()

# Running loop
for (i in 1:48) {
  tempmod <- ivreg(
    corruptrate_avg ~ ALDmean1970 + logarea + logMaxDistSt |
                      centr_ALDmean1970 + logarea + logMaxDistSt,
    data=dat[-i,])
  point_estimates[i] <- (tempmod$coefficients)[2]
}

# Plotting point estimates
pe <- data.frame(point_estimates)
fig2 <- ggplot(data=pe, aes(x=point_estimates)) +
  geom_histogram(binwidth = 0.01, fill="black", col="grey") +
  xlab("Point estimates") + ylab("Frequency") + themesettings +
  scale_x_continuous(breaks=seq(0.8,1.6,0.2), limits = c(0.8,1.6))
ggsave(paste0(outpath,"Fig2_R.png"),plot=fig2, width=14, height=10.1)



